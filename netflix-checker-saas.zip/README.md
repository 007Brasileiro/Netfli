# Netflix Checker SaaS

Aplicação web para verificação de credenciais Netflix a partir de arquivos .txt.

## Funcionalidades

- Upload de arquivo .txt com combos no formato `URL:Email:Senha`
- Filtragem automática de apenas combos Netflix
- Verificação real das credenciais (login na Netflix)
- Download dos resultados válidos
- Interface moderna e responsiva

## Formatos Suportados

```
netflix.com:email@exemplo.com:senha123
netflix:email@exemplo.com:senha123
email@exemplo.com:senha123
```

## Como Rodar

```bash
pip install -r requirements.txt
python app.py
```

Acesse em: http://localhost:5000

## Docker

```bash
docker build -t netflix-checker .
docker run -p 5000:5000 netflix-checker
```
